score=int(input("당신의 점수는 몇점인가요?"))
if score>=90:
    print("A")
elif 90>score>=80:
    print("B")
elif 80>score>=70:
    print("C")
else:
    print("F")
num1=int(input("첫번째 수 입력>"))
num2=int(input("두번째 수 입력>"))
if num1>num2:
    print("첫 번째 수가 큽니다.")
else:
    if num1==num2:
        print("입력된 두 수는 같습니다")
    else:
        print("두번째 수가 더 큽니다")
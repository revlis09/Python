a=input("윷의 결과를 입력해 주세요>")
c = a.count("1")
if c==1:
    print("도")
elif c==2:
    print("개")
elif c==3:
    print("걸")
elif c==4:
    print("윷")
elif c==0:
    print("모")
num=int(input("정수입력>"))
if num<0:
    print("음수입니다")
elif num==0:
    print("0입니다")
else:
    if num==0:
        print("0입니다")
    else:
        print("양수입니다/.")

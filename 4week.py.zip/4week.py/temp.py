temp=float(input("현재 온도 입력>"))
if temp>=25:
    print("반바지를 입으세요")
else:
    print("긴바지를 입으세요")
carspeed=int(input("현재 속도 입력>"))
if (carspeed > 50):
    print("과속입니다\n속도를 줄여주세요.")
else:
    print("정상속도 입니다.\n즐거운 하루 되세요.")
import turtle
t=turtle.Turtle()

for count in range(7):
  t.circle(100)
  t.right(60)

a=input()
sum=0
for i in a:
  if i=="a":
    sum +=1
print(sum)

array=[273, 74, 103, 57, 52]
sum=0
for i in array:
  print(sum, i)
  sum+=1
  
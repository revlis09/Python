n=int(input('정수입력>'))
result=1
for i in range(1, n+1):
  result *= i
print(n,"!은", result) 
import turtle
t=turtle.Turtle()
n=int(input('정수입력>'))
for i in range(n+1):
  t.forward(100)
  t.left(108)
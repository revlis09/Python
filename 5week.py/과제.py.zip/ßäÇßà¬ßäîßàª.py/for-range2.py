dan=int(input("원하는 단은: "))
for i in range(1, 10):
  print(f'{dan}*{i}={dan*i}')
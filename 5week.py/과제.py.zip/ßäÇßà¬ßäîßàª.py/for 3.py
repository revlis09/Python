a=int(input())
for i in range(a, a+1):
  print(i*"*")
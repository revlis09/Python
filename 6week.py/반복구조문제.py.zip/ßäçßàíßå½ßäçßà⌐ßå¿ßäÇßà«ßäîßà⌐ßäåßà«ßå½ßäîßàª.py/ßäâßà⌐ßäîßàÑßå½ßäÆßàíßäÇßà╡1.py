a=0
while a<5:
  print("안녕하세요")
  a+=1
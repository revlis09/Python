a=1
while a<=100:
  if a%3==0:
    print("짝", end=' ')
  else:
    print(a, end=' ')
  a=a+1
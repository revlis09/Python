sum=0
a=1
num=input("N값 입력: ")
num=int(num)
while a<=num:
  sum=sum+a
  a=a+1
print(sum)
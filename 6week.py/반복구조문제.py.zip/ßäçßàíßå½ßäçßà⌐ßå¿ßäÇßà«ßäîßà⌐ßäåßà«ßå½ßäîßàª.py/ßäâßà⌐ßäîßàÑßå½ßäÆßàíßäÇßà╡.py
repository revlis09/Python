dan=int(input("원하는 단은: "))
i=1
while i<10:
  a=i*dan
  print(dan, "*", i, "=", a)
  i+=1
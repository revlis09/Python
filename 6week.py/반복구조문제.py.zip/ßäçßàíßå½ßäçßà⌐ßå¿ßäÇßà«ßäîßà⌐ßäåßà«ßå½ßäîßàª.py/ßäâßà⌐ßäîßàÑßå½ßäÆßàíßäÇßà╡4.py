while True:
  n=input("y 입력시 종료> ")
  if n=="y":
    break

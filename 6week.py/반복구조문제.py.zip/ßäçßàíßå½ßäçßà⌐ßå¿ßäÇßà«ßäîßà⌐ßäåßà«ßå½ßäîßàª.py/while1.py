weight=70
while weight>60:
  print("운동하자")
  weight=weight-1
print("목표달성!")
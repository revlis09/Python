bts=['정국', '뷔', '지민', '슈가', '진', 'RM', '제이홈']
i=0
a=len(bts)
while i < a:
  print(bts[i])
  i+=1
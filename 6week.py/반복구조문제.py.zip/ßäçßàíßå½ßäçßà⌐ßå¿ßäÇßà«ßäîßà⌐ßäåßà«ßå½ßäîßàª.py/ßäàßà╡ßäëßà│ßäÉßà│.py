alist=[1, 2, 1, 2]
while 2 in alist:
  alist.remove(2)
print(alist)
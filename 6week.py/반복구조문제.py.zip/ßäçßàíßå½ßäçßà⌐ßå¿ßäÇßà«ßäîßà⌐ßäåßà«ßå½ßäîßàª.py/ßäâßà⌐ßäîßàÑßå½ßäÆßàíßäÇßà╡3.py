n=int(input("n: "))
while n>=0:
  print(n)
  n-=1
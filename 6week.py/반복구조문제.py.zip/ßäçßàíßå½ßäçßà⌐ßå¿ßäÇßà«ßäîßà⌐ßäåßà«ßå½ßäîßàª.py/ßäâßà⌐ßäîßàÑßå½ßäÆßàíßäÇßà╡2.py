n=int(input('n: '))
while n>0:
  print("실행")
  n-=1
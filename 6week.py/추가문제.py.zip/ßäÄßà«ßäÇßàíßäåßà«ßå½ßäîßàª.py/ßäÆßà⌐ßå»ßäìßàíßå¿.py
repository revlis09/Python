
for i in range(1, 31):
  if i%2==0:
    print(i, "짝수")
  else:
    print(i, "홀수")

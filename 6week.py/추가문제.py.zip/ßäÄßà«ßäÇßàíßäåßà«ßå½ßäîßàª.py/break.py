num=input("숫자 입력: ")
num=int(num)
for i in range(20):
  print(i, end=" ")
  if i==num:
    break
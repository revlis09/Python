n=input()
count=0
for i in n:
  if i=="2":
    count+=1
print(count)
a=[]
for i in range(5):
  n=input()
  a.append(n)
result=""
for j in range(5):
  result+=a[j][4-j]
print(result)

  


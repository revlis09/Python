food = input().split()
count=0
for i in food:
  count+=1
print("좋아하는 음식의 개수:", count)
for j in food:
  print(j)
score=[80,90,75,35,50]
for i in score:
  print(i)
score=[80,90,75,25,50]
for a in range(len(score)):
  print(score[a])
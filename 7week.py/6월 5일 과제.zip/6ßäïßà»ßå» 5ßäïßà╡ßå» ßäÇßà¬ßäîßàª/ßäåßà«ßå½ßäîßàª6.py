a=[7,6,5,4]
b=[1,2,3]
print(b+a)
print(a+b*2)
a_1=a[0:2]
b_1=b[0:2]
print(b_1+a_1*3)
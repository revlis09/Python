a=[1,2,3,4,5]
if 0 not in a:
  print('0이 존재하지 않습니다')
else:
  print('0이 존재합니다')
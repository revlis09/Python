alist=[11, 22, 33, 44]
sum=0
for i in alist:
  sum+=i
print(alist)
print(sum)
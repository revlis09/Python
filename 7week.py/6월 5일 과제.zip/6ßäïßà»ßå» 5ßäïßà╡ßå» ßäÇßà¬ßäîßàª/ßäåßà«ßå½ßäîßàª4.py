menu=[]
menu.append('치킨')
menu.append('피자')
menu.append('샐러드')
menu.append('스테이크')
print(menu)
menu[3]='감자튀김'
print("변경=>",menu)
menu.remove('샐러드')
print("삭제=>",menu)
print("샐러드 메뉴가 삭제 되었습니다")


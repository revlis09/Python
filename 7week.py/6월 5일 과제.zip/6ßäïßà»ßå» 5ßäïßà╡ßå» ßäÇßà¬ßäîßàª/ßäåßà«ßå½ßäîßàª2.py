a=['사과','바나나','포도','수박']
print(a[0:2])
print(a[1:4])
print(a[1:3])
print(a[0:4])

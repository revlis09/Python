a=[1,2,3,4,5]
if 1 in a:
  print('1이 존재합니다')
else:
  print('1이 존재하지 않습니다')